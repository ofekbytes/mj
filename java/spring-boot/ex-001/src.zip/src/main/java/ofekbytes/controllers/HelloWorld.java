package ofekbytes.controllers;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class HelloWorld {

	@RequestMapping("/")
	public String ofekbytes() {
		return "<h1>Main Page</h1>";
	}
	
	//"get" type request
	@RequestMapping("/hello")
	public String hello() {
		return "<h1>Hello</h1>";
	}
	
}
