package ofekbytes.readme;

public class UrlList {

	// fields
	private String stName;
	private String stDescription;
	private String stUrl;
	
	// name, description, url

	// no argument.
	public UrlList() {

	}

	
}
