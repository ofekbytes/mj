package ofekbytes.topic;

import java.util.Arrays;
import java.util.List;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class topicController {

	@RequestMapping("/topic")
	public String getAllTopic() {
		return "Current topic";
	}

	@RequestMapping("/topics")
	public List<Topic> getAllTopics() {
			
		return Arrays.asList(
				new Topic("science fiction","terminator","The Terminator is a 1984 science fiction film"),
				new Topic("science fiction","back to the future","Back to the Future is a 1985 American science fiction film "),
				new Topic("fantasy","field of dreams","Field of Dreams is a 1989 American sports fantasy drama ")			 
				) ;
	}
}
